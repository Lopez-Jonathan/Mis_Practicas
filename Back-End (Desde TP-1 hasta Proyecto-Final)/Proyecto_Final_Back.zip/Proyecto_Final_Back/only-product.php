<?php
session_start();
require 'funcs/conexion.php';
require 'funcs/funcs.php';

if(!isset($_SESSION["id_usuario"]))
{
  header("location: index.php");
}

$idUsuario = $_SESSION['id_usuario'];
$sql = "SELECT id, nombre FROM usuarios WHERE id = '$idUsuario'";
$result = $conexion->query($sql);

$row = $result->fetch_assoc();
?>

<?php
require 'funcs/conexion(2).php';

$id = $_GET["id"];
$consulta = "SELECT * FROM ropa WHERE ID=$id";
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Proyecto_Final (Backup 1655812244033)</title>
    <link rel="stylesheet" href="css/bootstrap.min.css(2)">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fonts/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/ionicons.min.css">
    <link rel="stylesheet" href="css/Footer-Dark.css">
    <link rel="stylesheet" href="css/Navigation-with-Search.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-lg navigation-clean-search">
        <div class="container"><img class="logo" src="img/ARMOR_free-file (1).png">
            <form class="me-auto search-form" target="_self">
                <div class="d-flex align-items-center"><input class="form-control search-field" type="search" id="search-field" name="search"><label class="form-label d-flex mb-0 label-loupe" for="search-field"><i class="fa fa-search loupe"></i></label></div>
            </form><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav">
                  <?php
                  if ($_SESSION['tipo_usuario']==2) {
                    ?>
                    <li class="nav-item"><a class="nav-link" href="welcomeusuario.php">Inicio</a></li>
                    <li class="nav-item"><a class="nav-link" href='logout.php'>Cerrar Sesi&oacute;n</a></li>
                    <li class="nav navbar-nav navbar-right"><?php echo 'Bienvenid@ '.utf8_decode($row['nombre']);?></li>
                    <?php
                  }else {
                    ?>
                    <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
                    <li class="nav-item"><a class="btn btn-light action-button" role="button" href="login.php">Ingresar/Registrarse</a></li>
                    <?php
                    }
                    ?>


                </ul>
            </div>
        </div>
    </nav>

    <?php
    $resultado=mysqli_query($conexion,$consulta);
    if (mysqli_num_rows($resultado)>0) {
      ?>
      <div class="container-fluid container-product">
      <?php
      while ($datos=mysqli_fetch_assoc($resultado)) {
        ?>
        <div id="carousel-photo" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active"><img class="d-block product" alt="product" src="data:image/jpg;base64, <?php echo base64_encode($datos['imagen'])?>"></div>
            <div class="carousel-item"><img class="d-block product" alt="product" src="data:image/jpg;base64, <?php echo base64_encode($datos['imagen'])?>"></div>
            <div class="carousel-item"><img class="d-block product" alt="product" src="data:image/jpg;base64, <?php echo base64_encode($datos['imagen'])?>"></div>
            <div class="carousel-item"><img class="d-block product" alt="product" src="data:image/jpg;base64, <?php echo base64_encode($datos['imagen'])?>"></div>
          </div>
          <a class="carousel-control-prev" href="#" type="button" data-bs-target="#carousel-photo" data-bs-slide="prev"><span class="carousel-control-prev-icon bg-dark border border-dark rounded-circle" aria-hidden="true"></span><span class="visually-hidden">Previous</span></a><a class="carousel-control-next" href="#" type="button" data-bs-target="#carousel-photo" data-bs-slide="next"><span class="carousel-control-next-icon bg-dark border border-dark rounded-circle" aria-hidden="true"></span><span class="visually-hidden">Next</span></a>
        </div>
        <div class="text-product">
          <div class="tittle-trolley">
            <h1><?php echo ucwords($datos['marca']) ?></h1><!--<a class="shopping-product" href="#"><i class="fa fa-shopping-cart trolley"></i></a> PENDIENTE CARRITO-->
          </div>
          <p>$<?php echo $datos['precio']; ?></p>
          <span><a class="btn btn-primary btn-buy" href="#">Comprar</a></span>
        </div>
        <?php
        }

        ?>
    </div>
    <?php
  }

    ?>


    <footer class="footer-dark footer-product">
        <div class="container">
            <div class="row">
                <div class="col-md-6 item text">
                    <h3>ARMOR</h3>
                    <p>Somos una empresa especializada en ropa, equipamiento y accesorios de gimnasio, que siempre busca brindar la mejor experiencia acompañada de, por que no, una buena rutina.</p>
                </div>
                <div class="col text-center item social" style="text-align: center;"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
            </div>
            <p class="copyright">ARMOR © 2022</p>
        </div>
    </footer>
    <script src="js/bootstrap.min.js(2)"></script>
</body>

</html>
