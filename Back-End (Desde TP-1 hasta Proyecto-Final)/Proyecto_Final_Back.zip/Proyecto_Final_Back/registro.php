<?php

	require 'funcs/conexion.php';
	require 'funcs/funcs.php';

	$errors = array();

	if(!empty ($_POST))
		{
			$nombre = $conexion->real_escape_string($_POST['nombre']);
			$usuario = $conexion->real_escape_string($_POST['usuario']);
			$password = $conexion->real_escape_string($_POST['password']);
			$con_password = $conexion->real_escape_string($_POST['con_password']);
			$email = $conexion->real_escape_string($_POST['email']);
			$captcha = $conexion->real_escape_string($_POST['g-recaptcha-response']);

			$activo = 0;
			$tipo_usuario = 2;
			$secret = "6LfCrvkfAAAAAEHN9JN_VFEgwL6RQSCSm_LCl6yw";

			if(!$captcha)
			{
				$errors [] = "Por favor verifica el captcha";
			}

			if(isNUll($nombre, $usuario, $password, $con_password, $email))
			{
				$errors [] = "Debe llenar todos los campos";
			}

			if(!isEmail($email))
			{
				$errors [] = "Direccion de Correo invalida";
			}

			if(!validaPassword ($password, $con_password))
			{
				$errors [] = "Las contraseñas no coinciden";
			}

			if(usuarioExiste($usuario))
			{
				$errors [] = "El nombre de usuario $usuario ya existe";
			}

			if(emailExiste($email))
			{
				$errors [] = "El nombre de usuario $email ya existe";
			}

			if(count($errors) == 0)
			{
				$response = file_get_contents(
					"https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");

				$arr = json_decode($response, true);

				if ($arr['success'])
				{

					$pass_hash = hashPassword($password);
					$token = generateToken();
					$registro = registraUsuario($usuario, $pass_hash, $nombre, $email,
					$activo, $token, $tipo_usuario);

					if($registro > 0)
					{
						$url = 'http://'.$_SERVER["SERVER_NAME"].
						'/Proyecto_Final_back/activar.php?id='.$registro.'&val='.$token;

						$asunto = 'Activar Cuenta - Sistema de Usuarios';
						$cuerpo = "Estimado $nombre: <br /> <br /> Para continuan con
						el proceso de registro, es indispensable que de click en el
						siguiente link <a href='$url'>Activar Cuenta</a>";

						if (enviarEmail($email, $nombre, $asunto, $cuerpo))
						{
							echo "Para terminar el proceso de registro siga las
							instrucciones que le hemos enviado a la direccion de correo
							electronico: $email";

							echo "<br><a href = 'index.php' >Iniciar Sesion</a>";
							exit;

						}else
						{
							$errors [] = "Error al enviar Email";
						}


					}else
					{
						$errors [] = "Error al Registrar";
					}
				}else
				{
					$error [] = "Error al comprobar Captcha";
				}
			}
		}

?>

<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Registro</title>
		<link rel="stylesheet" href="css/bootstrap.min.css(2)">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="fonts/font-awesome.min.css">
		<link rel="stylesheet" href="fonts/ionicons.min.css">
		<link rel="stylesheet" href="css/Footer-Dark.css">
		<link rel="stylesheet" href="css/Navigation-with-Search.css">
		<link rel="stylesheet" href="css/styles.css">
		<script src="js/bootstrap.min.js" ></script>
		<script src='https://www.google.com/recaptcha/api.js'></script>
	</head>

	<body>

		<nav class="navbar navbar-light navbar-expand-lg navigation-clean-search">
        <div class="container"><img class="logo" src="img/ARMOR_free-file%20(1).png">
            <!--<form class="me-auto search-form" target="_self">
                <div class="d-flex align-items-center"><input class="form-control search-field" type="search" id="search-field" name="search"><label class="form-label d-flex mb-0 label-loupe" for="search-field"><i class="fa fa-search loupe"></i></label></div>
            </form> NO SE USA EN LOGIN--><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
                    <!--<li class="nav-item"><a class="nav-link" href="#">Categorías</a></li> PENDIENTE-->
                    <!--<li class="nav-item"><a class="nav-link fa-regular fa-cart-shopping" href="#"><i class="fa fa-shopping-cart"></i></a></li> PENDIENTE-->
                    <!--<li class="nav-item"><a class="btn btn-light action-button" role="button" href="#">Ingresar/Registrarse</a></li> NO SE USA EN LOGIN-->
                </ul>
            </div>
        </div>
    </nav>

		<div class="container">
			<div id="signupbox" style="margin-top:135px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
				<div class="panel panel-info">
					<div class="panel-heading" style="background-color:#4b3621">
						<div class="panel-title" style="color:#eed09d">Reg&iacute;strate</div>
						<div style="float:right; font-size: 85%; position: relative; top:-10px"><a style="color:#db9c31" id="signinlink" href="login.php">Iniciar Sesi&oacute;n</a></div>
					</div>

					<div class="panel-body" >

						<form id="signupform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">

							<div id="signupalert" style="display:none" class="alert alert-danger">
								<p>Error:</p>
								<span></span>
							</div>

							<div class="form-group">
								<label for="nombre" class="col-md-3 control-label">Nombre:</label>
								<div class="col-md-9">
									<input type="text" class="form-control" name="nombre" placeholder="Nombre" value="<?php if(isset($nombre)) echo $nombre; ?>" required >
								</div>
							</div>

							<div class="form-group">
								<label for="usuario" class="col-md-3 control-label">Usuario</label>
								<div class="col-md-9">
									<input type="text" class="form-control" name="usuario" placeholder="Usuario" value="<?php if(isset($usuario)) echo $usuario; ?>" required>
								</div>
							</div>

							<div class="form-group">
								<label for="password" class="col-md-3 control-label">Password</label>
								<div class="col-md-9">
									<input type="password" class="form-control" name="password" placeholder="Password" required>
								</div>
							</div>

							<div class="form-group">
								<label for="con_password" class="col-md-3 control-label">Confirmar Password</label>
								<div class="col-md-9">
									<input type="password" class="form-control" name="con_password" placeholder="Confirmar Password" required>
								</div>
							</div>

							<div class="form-group">
								<label for="email" class="col-md-3 control-label">Email</label>
								<div class="col-md-9">
									<input type="email" class="form-control" name="email" placeholder="Email" value="<?php if(isset($email)) echo $email; ?>" required>
								</div>
							</div>

							<div class="form-group">
								<label for="captcha" class="col-md-3 control-label"></label>
								<div class="g-recaptcha col-md-9" data-sitekey="6LfCrvkfAAAAAFRYlAL1dmzFt_ogjzQGdTFiGnl-"></div>
							</div>

							<div class="form-group">
								<div class="col-md-offset-3 col-md-9">
									<button id="btn-signup" type="submit" class="btn" style="background-color:#4b3621; color:#eed09d"><i class="icon-hand-right"></i>Registrar</button>
								</div>
							</div>
						</form>
						<?php echo resultBlock($errors); ?>
					</div>
				</div>
			</div>
		</div>
		<footer class="footer-dark">
        <div class="container">
            <div class="row">
                <div class="col-md-6 item text">
                    <h3>ARMOR</h3>
                    <p>Somos una empresa especializada en ropa, equipamiento y accesorios de gimnasio, que siempre busca brindar la mejor experiencia acompañada de, por que no, una buena rutina.</p>
                </div>
                <div class="col text-center item social" style="text-align: center;"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
            </div>
            <p class="copyright">ARMOR © 2022</p>
        </div>
    </footer>
		<script src="js/bootstrap.min.js(2)"></script>
	</body>
</html>
