<?php
	session_start();
	require 'funcs/conexion.php';
	require 'funcs/funcs.php';

	if(!isset($_SESSION["id_usuario"]))
	{
		header("location: index.php");
	}

	$idUsuario = $_SESSION['id_usuario'];
	$sql = "SELECT id, nombre FROM usuarios WHERE id = '$idUsuario'";
	$result = $conexion->query($sql);

	$row = $result->fetch_assoc();

?>

<?php
require 'funcs/conexion(2).php';
if (!empty($_POST['buscar'])) {
	$buscar=$_POST['buscar'];
	$consulta="SELECT * FROM ropa WHERE tipo_de_prenda LIKE '%$buscar%' OR marca LIKE '%$buscar%' OR talle LIKE '%$buscar%'";
}else{
	$consulta="SELECT * FROM ropa";
}
?>

<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Bienvenido</title>
		<link rel="stylesheet" href="css/bootstrap.min.css(2)">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fonts/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/ionicons.min.css">
    <link rel="stylesheet" href="css/Footer-Dark.css">
    <link rel="stylesheet" href="css/Navigation-with-Search.css">
    <link rel="stylesheet" href="css/styles.css">
		<script src="js/bootstrap.min.js" ></script>
	</head>

	<body>
		<nav class="navbar navbar-light navbar-expand-lg navigation-clean-search">
        <div class="container"><img class="logo" src="img/ARMOR_free-file%20(1).png">
            <form class="me-auto search-form" target="_self"method="POST" action="<?php $_SERVER['PHP_SELF'];?>">
                <div class="d-flex align-items-center"><input class="form-control search-field" type="search" id="search-field" name="buscar"><label class="form-label d-flex mb-0 label-loupe" for="search-field"><i class="fa fa-search loupe"></i></label></div>
            </form><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="welcomeusuario.php">Inicio</a></li>
                    <!--<li class="nav-item"><a class="nav-link" href="#">Categorías</a></li> PENDIENTE-->
                    <!--<li class="nav-item"><a class="nav-link fa-regular fa-cart-shopping" href="#"><i class="fa fa-shopping-cart"></i></a></li> PENDIENTE-->
										<?php
										if ($_SESSION['tipo_usuario']==1) {
											?>
											<li class="nav-item"><a class="nav-link" href='agregar.html'>Agregar Producto</a></li>
											<?php
										}
										?>

										<li class="nav-item"><a class="nav-link" href='logout.php'>Cerrar Sesi&oacute;n</a></li>
										<li class="nav navbar-nav navbar-right"><?php echo 'Bienvenid@ '.utf8_decode($row['nombre']);?></li>
                </ul>
            </div>
        </div>
    </nav>

		<?php
    if (empty($buscar)) {
      ?>
      <div class="banner container-fluid">
          <div class="jumbotron">
              <h1 class="title">Lo mejor</h1>
              <p class="description">en ropa, accesorios y equipamiento de gimnasio.</p>
              <p><a class="btn btn-primary btn-lg button" href="#">Ver Productos</a></p>
          </div>
      </div>

		</div>
		<div class="banner2 container-fluid">
				<div class="jumbotron">
						<h1 class="title">Lo mejor</h1>
						<p class="description">en ropa, accesorios y equipamiento de gimnasio.</p>
						<p><a class="btn btn-primary btn-lg button" href="#">Ver Productos</a></p>
				</div>
		</div>
		<?php
	}
	?>

	<?php
	if (!empty($buscar) and $_SESSION['tipo_usuario']==2) {
		$resultado=mysqli_query($conexion,$consulta);
		if (mysqli_num_rows($resultado)>0) {
			?>
			<div class="container-fluid card-search">
				<?php
					while ($datos=mysqli_fetch_assoc($resultado)) {
						?>
						<div class="card col-sm-12 col-md-6 col-lg-3 card-modify">
							<img class="card-img-top img-modify" src="data:image/jpg;base64, <?php echo base64_encode($datos['imagen'])?>" alt="" width="150px" height="350px")>
							<!--<img class="card-img-top" src="data:image/jpg;base64, <?php //echo base64_encode($reg['imagen2'])?>" alt="" width="100px" height="100px")>-->
							<h3 class="card-title" style="width: 100%; font-size:25px;"><?php echo ucwords($datos['marca']) ?></h3>
							<span>$ <?php echo $datos['precio']; ?></span>
							<a class="btn btn-primary button" href="only-product.php?id=<?php echo $datos['ID'];?>">Comprar</a>
						</div>
						<?php
						}

						?>
				</div>
				<?php
				}
			}
			?>

			<?php
			if (!empty($buscar) and $_SESSION['tipo_usuario']==1) {
				$resultado=mysqli_query($conexion,$consulta);
				if (mysqli_num_rows($resultado)>0) {
					?>
					<table border="1" class="table">
			    <tr>
			        <th>ID</th>
			        <th>TIPO DE PRENDA</th>
			        <th>MARCA</th>
			        <th>TALLE</th>
			        <th>PRECIO</th>
			        <th>IMAGEN</th>
			        <th>EDITAR</th>
			        <th>BORRAR</th>
			    </tr>

					<?php
					while ($datos=mysqli_fetch_assoc($resultado)) {
						?>
						<tr>
		        <td><?php echo $datos['ID']; ?></td>
		        <td><?php echo $datos['tipo_de_prenda']; ?></td>
		        <td><?php echo $datos['marca']; ?></td>
		        <td><?php echo $datos['talle']; ?></td>
		        <td><?php echo $datos['precio']; ?></td>
		        <td><img src="data:image/png;base64, <?php echo base64_encode($datos['imagen'])?>" alt="" width="100px" height="100px"></td>
		        <td><a href="modificar.php?id=<?php echo $datos['ID'];?>">Editar</a></td>
		        <td><a href="borrar.php?id=<?php echo $datos['ID'];?>">Borrar</a></td>
		        </tr>
						<?php
					}

						?>
					 </table>

					 <?php
				 }
			 }
					 ?>

			<footer class="footer-dark">
	        <div class="container">
	            <div class="row">
	                <div class="col-md-6 item text">
	                    <h3>ARMOR</h3>
	                    <p>Somos una empresa especializada en ropa, equipamiento y accesorios de gimnasio, que siempre busca brindar la mejor experiencia acompañada de, por que no, una buena rutina.</p>
	                </div>
	                <div class="col text-center item social" style="text-align: center;"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
	            </div>
	            <p class="copyright">ARMOR © 2022</p>
	        </div>
	    </footer>
		<script src="js/bootstrap.min.js(2)"></script>
	</body>
</html>
