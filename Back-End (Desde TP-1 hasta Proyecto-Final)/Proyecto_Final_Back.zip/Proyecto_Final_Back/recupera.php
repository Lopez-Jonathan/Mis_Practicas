<?php
	require 'funcs/conexion.php';
	require 'funcs/funcs.php';

	$errors = array();
	if (!empty($_POST))
	{
		$email = $conexion->real_escape_string($_POST['email']);


		if(!isEmail($email))
		{
			$errors [] = "Debe ingresar un correo electronico valido";
		}
			if( emailExiste($email))
			{
				$user_id = getValor('id', 'correo' , $email);
				$nombre = getValor('nombre', 'correo' , $email);

				$token = generaTokenPass($user_id);

				$url = 'http://'.$_SERVER["SERVER_NAME"].
				'/Proyecto_Final_Back/cambia_pass.php?user_id='.$user_id.'&token='.$token;

				$asunto = 'Recuperar Password - Sistema de Usuarios';
				$cuerpo = "Hola $nombre: <br /><br />Se ha solicitado un reinicio de
				la contrase&ntilde;a. <br/><br/>Para restaurar la contrase&ntilde;a,
				visita la siguiente direcci&oacute;n: <a href = '$url'>$url</a>";

				if(enviarEmail($email, $nombre, $asunto, $cuerpo))
				{
					echo "Hemos enviado un correo electronico a la
					direccion $email para restablecer su password.<br />";
					echo "<a href = 'index.php' >Iniciar Sesion</a>";
					exit;
				}else
				{
					$errors [] = "Error al enviar Email";
				}
			}else
			{
				$errors [] ="No existe el correo electronico en nuestra base de datos";
			}
	}
?>
<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Recuperar Password</title>
		<link rel="stylesheet" href="css/bootstrap.min.css(2)">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="fonts/font-awesome.min.css">
		<link rel="stylesheet" href="fonts/ionicons.min.css">
		<link rel="stylesheet" href="css/Footer-Dark.css">
		<link rel="stylesheet" href="css/Navigation-with-Search.css">
		<link rel="stylesheet" href="css/styles.css">
		<script src="js/bootstrap.min.js" ></script>

	</head>

	<body>

		<nav class="navbar navbar-light navbar-expand-lg navigation-clean-search">
        <div class="container"><img class="logo" src="img/ARMOR_free-file%20(1).png">
            <!--<form class="me-auto search-form" target="_self">
                <div class="d-flex align-items-center"><input class="form-control search-field" type="search" id="search-field" name="search"><label class="form-label d-flex mb-0 label-loupe" for="search-field"><i class="fa fa-search loupe"></i></label></div>
            </form> NO SE USA EN LOGIN--><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
                    <!--<li class="nav-item"><a class="nav-link" href="#">Categorías</a></li> PENDIENTE-->
                    <!--<li class="nav-item"><a class="nav-link fa-regular fa-cart-shopping" href="#"><i class="fa fa-shopping-cart"></i></a></li> PENDIENTE-->
                    <!--<li class="nav-item"><a class="btn btn-light action-button" role="button" href="#">Ingresar/Registrarse</a></li> NO SE USA EN LOGIN-->
                </ul>
            </div>
        </div>
    </nav>

		<div class="container">
			<div id="loginbox" style="margin-top:135px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
				<div class="panel panel-info" >
					<div class="panel-heading" style="background-color:#4b3621">
						<div class="panel-title" style="color:#eed09d">Recuperar Password</div>
						<div style="float:right; font-size: 80%; position: relative; top:-10px"><a style="color:#db9c31" href="login.php">Iniciar Sesi&oacute;n</a></div>
					</div>

					<div style="padding-top:30px" class="panel-body" >

						<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>

						<form id="loginform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">

							<div style="margin-bottom: 25px" class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
								<input id="email" type="email" class="form-control" name="email" placeholder="email" required>
							</div>

							<div style="margin-top:10px" class="form-group">
								<div class="col-sm-12 controls">
									<button id="btn-login" type="submit" class="btn" style="background-color:#4b3621; color:#eed09d">Enviar</a>
								</div>
							</div>

							<div class="form-group">
								<div class="col-md-12 control" style="background-color:#4b3621">
									<div style="border-top: 1px solid#888; padding-top:15px; font-size:85%;color:#eed09d" >
										No tiene una cuenta! <a style="color:#db9c31" href="registro.php">Registrate aquí</a>
									</div>
								</div>
							</div>
						</form>
						<?php echo resultBlock($errors); ?>
					</div>
				</div>
			</div>
		</div>
		<footer class="footer-dark">
        <div class="container">
            <div class="row">
                <div class="col-md-6 item text">
                    <h3>ARMOR</h3>
                    <p>Somos una empresa especializada en ropa, equipamiento y accesorios de gimnasio, que siempre busca brindar la mejor experiencia acompañada de, por que no, una buena rutina.</p>
                </div>
                <div class="col text-center item social" style="text-align: center;"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
            </div>
            <p class="copyright">ARMOR © 2022</p>
        </div>
    </footer>
		<script src="js/bootstrap.min.js(2)"></script>
	</body>
</html>
