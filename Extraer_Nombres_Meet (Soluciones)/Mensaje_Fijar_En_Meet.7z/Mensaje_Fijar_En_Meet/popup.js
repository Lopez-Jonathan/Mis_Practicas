document.getElementById('sendMessage').addEventListener('click', () => {
    const message = `
    Se presenta en pantalla la información clave para tener el contexto de los incidentes en curso:
    ¿Qué está sucediendo? Puedes verlo en "What is Going On?".
    Afectación del incidente: Se detalla en "Incident".
    Duración del problema: El tiempo desde el inico se muestra en "Downtime Start".
    Operador NOC responsable: Identificado en "NOC Operator".
    Responsables de Comando y SRE: Puedes encontrarlos en "Commanders y SRE".
    Feedback =>  URL: https://forms.gle/5cRVXo4ZA135Xwcm8  
`;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: (msg) => {
                const input = document.querySelector('textarea[jsname="YPqjbf"]');
                if (!input) {
                    console.error('No se encontró el área de entrada.');
                    return;
                }

                input.focus();
                input.value = msg; 
                const event = new Event('input', { bubbles: true });
                input.dispatchEvent(event); 

                const sendButton = document.querySelector('button[aria-label="Envía un mensaje"], button[jsname="SoqoBf"]');
                if (!sendButton) {
                    console.error('No se encontró el botón de enviar.');
                    return;
                }

                setTimeout(() => {
                    sendButton.click();

                    
                    setTimeout(() => {
                        const pinButton = document.querySelector('button[aria-label="Fijar mensaje"], button[jsname="iJEnyb"]');
                        if (pinButton) {
                            pinButton.click();
                            console.log('Mensaje fijado.');
                        } else {
                            console.error('No se encontró el botón de fijar mensaje.');
                        }
                    }, 1000); 
                }, 1500); 
            },
            args: [message]
        });
    });
});
