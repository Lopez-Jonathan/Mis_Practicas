const axios = require('axios');

const url = 'https://internal-api.mercadolibre.com/im/incidents/api/v1/metadata/platform_metric';

async function fetchData() {
    try {
        const response = await axios.get(url);
        console.log('Datos recibidos:', response.data);
    } catch (error) {
        console.error('Error al hacer la solicitud:', error);
    }
}

fetchData()