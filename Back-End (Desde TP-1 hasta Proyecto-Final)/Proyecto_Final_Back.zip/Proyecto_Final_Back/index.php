<?php
require 'funcs/conexion(2).php';

if (!empty($_POST['buscar'])) {
  $buscar=$_POST['buscar'];
  $consulta="SELECT * FROM ropa WHERE tipo_de_prenda LIKE '%$buscar%' OR marca LIKE '%$buscar%' OR talle LIKE '%$buscar%'";
}else{
  $consulta="SELECT * FROM ropa";
}
 ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Proyecto_Final (Backup 1655812244033)</title>
    <link rel="stylesheet" href="css/bootstrap.min.css(2)">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fonts/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/ionicons.min.css">
    <link rel="stylesheet" href="css/Footer-Dark.css">
    <link rel="stylesheet" href="css/Navigation-with-Search.css">
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-lg navigation-clean-search">
        <div class="container"><img class="logo" src="img/ARMOR_free-file%20(1).png">
            <form class="me-auto search-form" target="_self"method="POST" action="<?php $_SERVER['PHP_SELF'];?>">
                <div class="d-flex align-items-center"><input class="form-control search-field" type="search" id="search-field" name="buscar"><label class="form-label d-flex mb-0 label-loupe" for="search-field"><i class="fa fa-search loupe"></i></label></div>
            </form><button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
                    <!--<li class="nav-item"><a class="nav-link" href="#">Categorías</a></li> PENDIENTE-->
                    <!--<li class="nav-item"><a class="nav-link fa-regular fa-cart-shopping" href="#"><i class="fa fa-shopping-cart"></i></a></li> PENDIENTE-->
                    <li class="nav-item"><a class="btn btn-light action-button" role="button" href="login.php">Ingresar/Registrarse</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <?php
    if (empty($buscar)) {
      ?>
      <div class="banner container-fluid">
          <div class="jumbotron">
              <h1 class="title">Lo mejor</h1>
              <p class="description">en ropa, accesorios y equipamiento de gimnasio.</p>
              <p><a class="btn btn-primary btn-lg button" href="#">Ver Productos</a></p>
          </div>
      </div>
      <!--<div id="carousel" class="carousel slide" data-bs-ride="carousel">
          <div class="carousel-inner carousel-product">
              <div class="carousel-item active row">
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
              </div>
              <div class="carousel-item row">
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
              </div>
              <div class="carousel-item row">
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
                  <div class="card col-sm-12 col-md-6 col-lg-3"><img class="card-img-top img-product" src="assets/img/ARMOR.png">
                      <hr>
                      <h1 class="card-title" style="width: 100%; font-size:25px;">Heading</h1><span>Descripcion</span><a class="btn btn-primary button" href="#">Link</a>
                  </div>
              </div>
          </div><a class="carousel-control-prev" href="#carousel" type="button" data-bs-target="#carousel" data-bs-slide="prev"><span class="carousel-control-prev-icon bg-dark border border-dark rounded-circle" aria-hidden="true"></span><span class="visually-hidden">Previous</span></a><a class="carousel-control-next" href="#carousel" type="button" data-bs-target="#carousel" data-bs-slide="next"><span class="carousel-control-next-icon bg-dark border border-dark rounded-circle" aria-hidden="true"></span><span class="visually-hidden">Next</span></a> PENDIENTE -->
      </div>
      <div class="banner2 container-fluid">
          <div class="jumbotron">
              <h1 class="title">Lo mejor</h1>
              <p class="description">en ropa, accesorios y equipamiento de gimnasio.</p>
              <p><a class="btn btn-primary btn-lg button" href="#">Ver Productos</a></p>
          </div>
      </div>
      <?php
    }
    ?>

    <?php
    if (!empty($buscar)) {
      $resultado=mysqli_query($conexion,$consulta);
      if (mysqli_num_rows($resultado)>0) {
        ?>
        <div class="container-fluid card-search">
          <?php
            while ($datos=mysqli_fetch_assoc($resultado)) {
              ?>
              <div class="card col-sm-12 col-md-6 col-lg-3 card-modify">
                <img class="card-img-top img-modify" src="data:image/jpg;base64, <?php echo base64_encode($datos['imagen'])?>" alt="" width="150px" height="350px")>
                <!--<img class="card-img-top" src="data:image/jpg;base64, <?php //echo base64_encode($reg['imagen2'])?>" alt="" width="100px" height="100px")>-->
                <h3 class="card-title" style="width: 100%; font-size:25px;"><?php echo ucwords($datos['marca']) ?></h3>
                <span>$ <?php echo $datos['precio']; ?></span>
                <a class="btn btn-primary button" href="login.php">Comprar</a>
              </div>
              <?php
              }

              ?>
          </div>
          <?php
          }
        }
        ?>




    <footer class="footer-dark">
        <div class="container">
            <div class="row">
                <div class="col-md-6 item text">
                    <h3>ARMOR</h3>
                    <p>Somos una empresa especializada en ropa, equipamiento y accesorios de gimnasio, que siempre busca brindar la mejor experiencia acompañada de, por que no, una buena rutina.</p>
                </div>
                <div class="col text-center item social" style="text-align: center;"><a href="#"><i class="icon ion-social-facebook"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-instagram"></i></a></div>
            </div>
            <p class="copyright">ARMOR © 2022</p>
        </div>
    </footer>
    <script src="js/bootstrap.min.js(2)"></script>
</body>

</html>
